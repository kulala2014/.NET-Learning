﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chromosphere.App.Common
{
    public enum BallType
    {
        RedBall,
        BlueBall
    }
}
