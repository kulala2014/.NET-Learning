﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chromosphere.App.Common
{
    public static class StaticConstant
    {
        public static readonly string RedBall = ConfigurationManager.AppSettings["RedBall"];
        public static readonly string BlueBall = ConfigurationManager.AppSettings["BlueBall"];
    }
}
