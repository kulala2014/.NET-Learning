﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Chromosphere.App.Common
{
    public static class Utilities
    {

        public static string GetRandomNum(BallType type)
        {
            string[] ballList = { };
            switch (type)
            {
                case BallType.BlueBall:
                    ballList = StaticConstant.BlueBall.Split(',');
                    break;
                case BallType.RedBall:
                    ballList = StaticConstant.RedBall.Split(',');
                    break;
            }

            return ballList[GetRandomNum(0, ballList.Length)];
        }

        private static int GetRandomNum(int min, int max)
        {
            Thread.Sleep(GetRandomNumCore(50, 100));
            return GetRandomNumCore(min, max);
        }

        private static int GetRandomNumCore(int min, int max)
        {
            Guid guidNum =  Guid.NewGuid();
            string guid = guidNum.ToString();
            int seed = DateTime.Now.Millisecond;
            for (int i = 0; i< guid.Length; i++)
            {
                switch (guid[i])
                {
                    case 'a':
                    case 'b':
                    case 'c':
                    case 'd':
                    case 'e':
                    case 'f':
                    case 'g':
                        seed = seed + 1;
                        break;
                    case 'h':
                    case 'i':
                    case 'j':
                    case 'k':
                    case 'l':
                    case 'm':
                    case 'n':
                        seed = seed + 2;
                        break;
                    case 'o':
                    case 'p':
                    case 'q':
                    case 'r':
                    case 's':
                    case 't':
                        seed = seed + seed;
                        break;
                    case 'u':
                    case 'v':
                    case 'w':
                    case 'x':
                    case 'y':
                    case 'z':
                        seed = seed + 3;
                        break;
                    default:
                        seed = seed + 4;
                        break;
                }
            }

            return new Random(seed).Next(min, max);
        }
    }
}
