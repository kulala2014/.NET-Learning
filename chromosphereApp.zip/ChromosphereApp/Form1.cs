﻿using Chromosphere.App.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChromosphereApp
{
    public partial class Form1 : Form
    {
        private static bool IsBegin = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void StartBtn_Click(object sender, EventArgs e)
        {
            TaskFactory taskFactory = new TaskFactory();
            List<Task> taskList = new List<Task>();
            this.button1.Enabled = false;
            this.button2.Enabled = true;
            IsBegin = true;
            //this.Controls
            foreach (var control in groupBox1.Controls)
            {

                if (control is Label)
                {
                    Label label = (Label)control;
                    taskList.Add(Task.Run(() => 
                    {
                        while (IsBegin)
                        {
                            UpdateLabelName(label);
                        }
                    }));
                }
            }
            taskFactory.ContinueWhenAll(taskList.ToArray(),t=> { ShowNumber(); });
        }

        private void EndBtb_Click(object sender, EventArgs e)
        {
            IsBegin = false;
            this.button1.Enabled = true;
            this.button2.Enabled = false;
        }

        private void UpdateLabelName(Label label)
        {
            if (label.ForeColor.Equals(Color.Red))
            {
               string randomValue =  Utilities.GetRandomNum(BallType.RedBall);
                lock (_LOCK)
                {
                    var numList = GetNumList();
                    if (!numList.Contains(randomValue))
                    {
                        this.Invoke(new Action(() =>
                        {
                            label.Text = randomValue;
                        }));
                    }
                }

            }
            else
            {
                string randomValue = Utilities.GetRandomNum(BallType.BlueBall);
                this.Invoke(new Action(() =>
                {
                    label.Text = randomValue;
                })); ;
            }
        }

        private readonly static object _LOCK = new object();

        private List<string> GetNumList()
        {
            List<string> strList = new List<string>();
            foreach (Control item in groupBox1.Controls)
            {
                if (item is Label)
                {
                    Label label = (Label)item;
                    strList.Add(label.Text);
                }
            }
            return strList;
        }
        private void ShowNumber()
        {
            MessageBox.Show(string.Format("本期双色球结果是 {0} {1} {2} {3} {4} {5}  {6}",
                  label1.Text, label2.Text, label3.Text,label4.Text, label5.Text, label6.Text, label7.Text));
        }
    }

    
}
